-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `counters` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_login` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_1` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_2` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soc_vk_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soc_fb_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soc_twt_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `soc_ok_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `addr` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `skype` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `viber` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telegram` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `counters`, `admin_login`, `admin_pass`, `phone_1`, `phone_2`, `email_1`, `email_2`, `soc_vk_url`, `soc_fb_url`, `soc_twt_url`, `soc_ok_url`, `company`, `addr`, `skype`, `viber`, `telegram`, `admin_email`) VALUES
(1,	'company',	'',	'',	'0123456789',	'',	'',	'',	'',	'',	'',	'',	'mycompany',	'',	'',	'',	'',	'');

-- 2020-11-30 08:57:12
